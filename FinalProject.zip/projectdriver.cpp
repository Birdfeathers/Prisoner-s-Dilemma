#include <iostream>
using namespace std;
#include <time.h>
#include <cmath>
#include <vector>
#include <fstream>
#include "project.hpp"


void runGame()
{
  string Orgname;
  string Envname;
  string outName;
  cout << "What organism file would you like to use?" << endl;
  getline(cin, Orgname);
  bool end = false;
  while(!end)
  {
    cout << "What environment file would you like to use?" << endl;
    getline(cin, Envname);
    environment e;
    e.readOrgFile(Orgname);
    e.readEnvFile(Envname);
    cout << "What file would you like to write the result to?" << endl;
    getline(cin, outName);
    e.writeProgressFile(outName);
    cout << "Would you like to run another environment?(y/n)" << endl;
    string user_response;
    getline(cin, user_response);
    if(user_response[0] == 'n' || user_response[0] == 'N') end = true;
  }
  cout << "end" << endl;
}

bool round(organism one, int b)
{
  bool returnVal;
  switch(b)
  {
    case 0: // returnFalse
      return false;
    case 1: // returnTrue
      return true;
    case 2: // returnLast
      return one.last;
    case 3: // returnRandom
      return  rand() % 2;
    case 4: // returnAverage - average of other's history so far
      returnVal = 2 * (one.OthersHistory / one.roundsSoFar);
      return returnVal;
    case 5: // return average of rounds this turn
      returnVal = 2 * (one.interactionsThisTurn / one.roundsThisTurn);
      return returnVal;
    case 6: // return the reverse of last turn
      return !one.last;
    // case 7: //
    //   if(one.interactionsThisTurn / one.o1 -> roundsThisTurn < organism.behavior.lowCuttOff) return true;
    //   return false;
    // case 8:
    //   if(one.interactionsThisTurn/one.o1 -> roundsThisTurn > organism.behavior.highCuttOff) return true;
    //   return false;
    // case 9:
    //   if(one.OthersHistory > organism.behavior.highCuttOff) return true;
    //   return false;


  }
  return false;

}

int main()
{

  runGame();




}
