#include <iostream>
using namespace std;
#include <time.h>
#include <cmath>
#include <vector>
#include <queue>


#ifndef PROJECT_HPP
#define PROJECT_HPP

/*
round: one face off
turn: number of face offs before and of two paired off
after being paired off

true = cooperate
false = don't cooperate
*/

// int returnFalse = 0;
// int returnTrue = 1;
// int returnLast = 2;
// int returnRandom = 3;
// int returnAverage = 4;
// int returnAveRound = 5;
// int returnReverseLast = 6;
// int isLessThan = 7;
// int isGreaterThan = 8;
// int isGreaterThanGame = 9;


struct behaviorT // behavior toward one type of oragnism
{
  // behavior in vert first interaction in game
  int first;
  // behavior in first interaction with this indivual
  int New;
  // following if last was uncooperative
  int cfol;
  // following if unccoperative
  int ufol;
};



struct behavior
{
  behaviorT family; // behavior toward family
  behaviorT friends; // behavior toward friends
  behaviorT bad; // behavior toward bad list
  behaviorT others; // behavior toward others
  // decision: good bad or neutral
  double highCuttOff; // cutoff for choosing to make freind
  double lowCuttOff; // cutoff for choosing to make badlist



};


struct organism
{
  bool last; // other's response last interaction
  int roundsSoFar = 0; // total rounds in game so far
  int roundsThisTurn = 0; // rounds since playing with same organism
  int personalhistory = 0; // total personal history in game so far
  int OthersHistory = 0; // total other's history in game so far
  int interactionsThisTurn = 0; // other's interactions this turn
  int number = 0; // number of this program in porganisms, id in organisms
  string name; // name of this strategy
  vector <int> family;
  vector <int> friends;
  vector <int> badlist;
  int resources = 0;
  behavior Behavior;
  bool pairedOff;
  int distance;

};



class environment
{
private:
  int turnsSoFar = 0;
  int currentNum = 0; // id to give to next organism;
  int roundsPerTurn;
  int pfamily; // percent of interactions with family
  int pfriends; // percent of interactions with friends
  int pother; // percent of interactions with others
  int memorylength; // how many organisms each organism can remember in its List
  int rumorLength; // how close to spread rumors
  vector <organism> organisms;
  vector <organism> porganisms; // possible organisms
  organism findPorganism(string name);
  int sumAll();
  void setPairedOffFalse();
  int findrandom();
  void faceOff(organism* o1, organism* o2);
  bool checkFamily(organism* o1, organism* o2);
  bool checkFriends(organism* o1, organism* o2, bool checkR);
  bool checkBad(organism* o1, organism* o2, bool checkR);
  void setDistNeg();
  organism* findOrganism(int number);
  bool check(organism* o1,string type);
public:
  void readOrgFile(string Orgname);
  void readEnvFile(string Envname);
  behaviorT createNewBT(int First, int New, int cfol, int ufol);
  behavior createNewbehavior(behaviorT fam, behaviorT friends, behaviorT bad, behaviorT others, double low, double high);
  organism createNewOrganism(behavior b, string name);
  void addOrganismType(string name);
  void writeProgressFile(string name);
  void takeTurn(int number);
  void addFriend(organism* o1, organism* o2);
  void addBad(organism* o1, organism* o2);
  void addFamily(organism* parent, organism* child);
  void resetOrganism(organism* o1);
  void reproduce();
  void reduce();
  vector<int> findDistances(organism* o1);
  bool rumorFriend(organism* o1, organism* o2);
  bool rumorBad(organism* o1, organism* o2);
  void eraseFromMemory(int number);

};

// bool Round(organism one, int b)
// {
//   bool returnVal;
//   switch(b)
//   {
//     case 0: // returnFalse
//       return false;
//     case 1: // returnTrue
//       return true;
//     case 2: // returnLast
//       return one.last;
//     case 3: // returnRandom
//       return  rand() % 2;
//     case 4: // returnAverage - average of other's history so far
//       returnVal = 2 * (one.OthersHistory / one.roundsSoFar);
//       return returnVal;
//     case 5: // return average of rounds this turn
//       returnVal = 2 * (one.interactionsThisTurn / one.roundsThisTurn);
//       return returnVal;
//     case 6: // return the reverse of last turn
//       return !one.last;
//     // case 7: //
//     //   if(one.interactionsThisTurn / one.roundsThisTurn < organism.behavior.lowCuttOff) return true;
//     //   return false;
//     // case 8:
//     //   if(one.interactionsThisTurn/one.roundsThisTurn > organism.behavior.highCuttOff) return true;
//     //   return false;
//     // case 9:
//     //   if(one.OthersHistory > organism.behavior.highCuttOff) return true;
//     //   return false;
//
//
//   }
//   return false;
//
// }

#endif
