#include <iostream>
using namespace std;
#include <time.h>
#include <cmath>
#include <iomanip>
#include <vector>
#include <queue>
#include <fstream>
#include "project.hpp"

int returnFalse = 0;
int returnTrue = 1;
int returnLast = 2;
int returnRandom = 3;
int returnAverage = 4;
int returnAveRound = 5;
int returnReverseLast = 6;
int isLessThan = 7;
int isGreaterThan = 8;
int isGreaterThanGame = 9;

organism* environment :: findOrganism(int number)
{
  for(int i = 0; i < organisms.size(); i++)
  {
    if(organisms[i].number == number){
    return &organisms[i];
    }
  }
  cout << "notfound" << endl;
  return nullptr;
}

bool Round(organism one, int b)
{
  bool returnVal;
  switch(b)
  {
    case 0: // returnFalse
      return false;
    case 1: // returnTrue
      return true;
    case 2: // returnLast
      return one.last;
    case 3: // returnRandom
      return  rand() % 2;
    case 4: // returnAverage - average of other's history so far
      returnVal = 2 * (one.OthersHistory / one.roundsSoFar);
      // cout << "Other's history" << one.OthersHistory << endl;
      // cout << "RoundsSoFar" << one.roundsSoFar << endl;
      // cout << "ReturnVal" << returnVal << endl;
      return returnVal;
    case 5: // return average of rounds this turn
      returnVal = 2 * (one.interactionsThisTurn / one.roundsThisTurn);
      return returnVal;
    case 6: // return the reverse of last turn
      return !one.last;
    // case 7: //
    //   if(one.interactionsThisTurn / one.o1 -> roundsThisTurn < organism.behavior.lowCuttOff) return true;
    //   return false;
    // case 8:
    //   if(one.interactionsThisTurn/one.o1 -> roundsThisTurn > organism.behavior.highCuttOff) return true;
    //   return false;
    // case 9:
    //   if(one.OthersHistory > organism.behavior.highCuttOff) return true;
    //   return false;


  }
  return false;

}

int split(string split, char del,string arr[] , int length)
{
    int splitlength = split.length();
    int entry = 0, wordlength=0, i=0;
    for( i; entry < length && i < splitlength; i++ )
     {
       if(split[i] != del)
         {
            while(split[i] != del&& i < splitlength)
            {
                i++;
                wordlength++;
            }
            arr[entry]= split.substr(i-wordlength, wordlength);
            wordlength =0;
            entry++;
         }
     }
    for(i; i < splitlength; i++)
    {
        if(split[i] != del) return -1;
    }
    return entry;

}
behaviorT environment :: createNewBT(int First, int New, int cfol, int ufol)
{
  behaviorT newbt;
  newbt.first = First;
  newbt.New = New;
  newbt.cfol = cfol;
  newbt.ufol = ufol;
  return newbt;
}
behavior environment :: createNewbehavior(behaviorT fam, behaviorT friends, behaviorT bad, behaviorT others, double low, double high)
{
  behavior b;
  b.family = fam;
  b.friends = friends;
  b.bad = bad;
  b.others = others;
  b.lowCuttOff = low;
  b.highCuttOff = high;
  return b;
}

organism environment :: createNewOrganism(behavior b, string name)
{
  organism o;
  o.Behavior = b;
  o.name = name;
  return o;
}

void environment :: readOrgFile(string Orgname)
{
  ifstream org;
  org.open(Orgname);
  string line;
  organism O;
  behaviorT bfriend;
  behaviorT bfam;
  behaviorT bbad;
  behaviorT bother;
  behavior B;
  float low;
  float high;
  string arr[6];
  string name;
  while(getline(org, line))
  {
    if(line == "New organism")
    {
      while(line != "end" )
      {
        getline(org, line);
        split(line, ':',arr, 6 );
        if(arr[0] == "name") name = arr[1];
        if(arr[0] == "Bfam")
        {
          split(arr[1], ',', arr, 6);
          bfam = createNewBT(stoi(arr[0]), stoi(arr[1]), stoi(arr[2]), stoi(arr[3]));
        }
        if(arr[0] == "Bfriend")
        {
          split(arr[1], ',', arr, 6);
          bfriend = createNewBT(stoi(arr[0]), stoi(arr[1]), stoi(arr[2]), stoi(arr[3]));
        }
        if(arr[0] == "Bbad")
        {
          split(arr[1], ',', arr, 6);
          bbad = createNewBT(stoi(arr[0]), stoi(arr[1]), stoi(arr[2]), stoi(arr[3]));
        }
        if(arr[0] == "Bother")
        {
          split(arr[1], ',', arr, 6);
          bother = createNewBT(stoi(arr[0]), stoi(arr[1]), stoi(arr[2]), stoi(arr[3]));
        }
        if(arr[0] == "Lowcutoff") low = stof(arr[1]);
        if(arr[0] == "highCuttOff") high = stof(arr[1]);
      }
      B = createNewbehavior(bfam, bfriend, bbad, bother, low, high);
      O = createNewOrganism(B, name);
      porganisms.push_back(O);

    }
  }
  org.close();
}

organism environment :: findPorganism(string name)
{
  organism o;
  for(int i = 0; i < porganisms.size(); i++)
  {
    if(porganisms[i].name == name)
    {
      behaviorT Friend = createNewBT(porganisms[i].Behavior.friends.first, porganisms[i].Behavior.friends.New, porganisms[i].Behavior.friends.cfol, porganisms[i].Behavior.friends.ufol);
      behaviorT fam = createNewBT(porganisms[i].Behavior.family.first, porganisms[i].Behavior.family.New, porganisms[i].Behavior.family.cfol, porganisms[i].Behavior.family.ufol);
      behaviorT bad = createNewBT(porganisms[i].Behavior.bad.first, porganisms[i].Behavior.bad.New, porganisms[i].Behavior.bad.cfol, porganisms[i].Behavior.bad.ufol);
      behaviorT other = createNewBT(porganisms[i].Behavior.others.first, porganisms[i].Behavior.others.New, porganisms[i].Behavior.others.cfol, porganisms[i].Behavior.others.ufol);
      behavior behave = createNewbehavior(fam, Friend, bad, other, porganisms[i].Behavior.lowCuttOff, porganisms[i].Behavior.highCuttOff);
      o = createNewOrganism(behave, name);
      o.number = currentNum;
      currentNum++;
      porganisms[i].number++;
    }
  }

  return o;
}

void environment :: addOrganismType(string name)
{
  organism o = findPorganism(name);
  organisms.push_back(o);
}

void environment :: readEnvFile(string Envname)
{
  ifstream Env;
  Env.open(Envname);
  string line;
  string arr[5];
  string arr2[porganisms.size() + 1];
  while(getline(Env, line))
  {
    split(line, '=', arr, 5);
    if(arr[0] == "roundsPerTurn"){
     roundsPerTurn = stoi(arr[1]);
    }
    if(arr[0] == "pfamily") pfamily = stoi(arr[1]);
    if(arr[0] == "pfriends") pfriends = stoi(arr[1]);
    if(arr[0] == "pother") pother = stoi(arr[1]);
    if(arr[0] == "memorylength") memorylength = stoi(arr[1]);
    if(arr[0] == "rumorLength") rumorLength = stoi(arr[1]);
    if(arr[0] == "listOrganisms")
    {
      int length = split(arr[1], ',', arr2, porganisms.size() + 1);
      for(int i = 0; i < porganisms.size() && i < length; i++)
      {
        string arr3[2];
        split(arr2[i], ';', arr3, 2);
        for(int j = 0; j < stoi(arr3[0]); j++)
        {
          addOrganismType(arr3[1]);
        }
      }
    }
  }
  Env.close();
}

int environment :: sumAll()
{
  int sum = 0;
  for(int i = 0; i < porganisms.size(); i++)
  {
    sum += porganisms[i].number;
  }
  return sum;
}

bool isValidNumber(string response)
{
  for(int i = 0; i < response.length(); i++)
  {
    if(!isdigit(response[i])) return false;
  }
  return true;
}

void environment :: writeProgressFile(string name)
{
  ofstream out;
  out.open(name);
  out << "Environment" << endl;
  out << "roundsPerTurn: " << roundsPerTurn << " , % family: " << pfamily << " , % friends: " << pfriends << " , % others: " << pother << endl;
  out << "memorylength: " << memorylength << ", rumorLength: " << rumorLength << endl;
  out << "---------------------------------------------------------------------------- " << endl;
  bool end = false;
  string user_response;
  while(!end){
    cout << "How many rounds would you like run?" << endl;
    getline(cin, user_response );
    if(isValidNumber(user_response)){
      takeTurn(stoi(user_response));
      out << "Organisms at turn:" << turnsSoFar << endl;
      out << "-----------------------" << endl;
      for(int i = 0; i < porganisms.size(); i++)
      {
        out << fixed << setprecision(2) << float(porganisms[i].number) / organisms.size() * 100 << "%" << ": " << porganisms[i].number << ", " <<  porganisms[i].name << endl;
      }
      out << endl;
      cout << "Would you like to run the program longer?(y/n)" << endl;
      getline(cin, user_response);
      if(user_response[0] == 'n' || user_response[0] == 'N') end = true;
    }
    else{
      cout << "invalid response" << endl;
    }
  }
  out.close();
}

void environment :: setPairedOffFalse()
{
  for(int i = 0; i < organisms.size(); i++)
  {
    organisms[i].pairedOff = false;
  }
}
bool environment :: check(organism* o1,string type) // checks if there are available friends/ family
{
  if(type == "family")
  {
    for(int i = 0; i < o1 -> family.size(); i++)
    {
      if(!findOrganism(o1 -> family[i]) ->pairedOff) return true;
    }
  }
  else
  {
    for(int i = 0; i < o1 -> friends.size(); i++)
    {
      if(!findOrganism(o1 -> friends[i]) -> pairedOff) return true;
    }
  }
  return false;
}

int environment :: findrandom()
{
  bool found = false;
  while(!found)
  {
    int random = rand() % organisms.size();
    if(!organisms[random].pairedOff)
    {
      found = true;
      organisms[random].pairedOff = true;
      return random;
    }
  }
  cout << "-1" << endl;
  return -1;
}
void environment :: faceOff(organism* o1, organism* o2)
{
  bool o1strat;
  bool o2strat;
  if(checkFamily(o1, o2))
  {
    if(o1 -> roundsSoFar == 0) o1strat = Round(*o1, o1 -> Behavior.family.first);
    else if(o1 -> roundsThisTurn == 0) o1strat = Round(*o1, o1 -> Behavior.family.New);
    else if(o1 -> last) o1strat = Round(*o1,o1 -> Behavior.family.cfol);
    else o1strat = Round(*o1,o1 -> Behavior.family.ufol);
    // now for the other
    if(o2 -> roundsSoFar == 0) o2strat = Round(*o2, o2 -> Behavior.family.first);
    else if(o2 -> roundsThisTurn == 0) o2strat = Round(*o2, o2 -> Behavior.family.New);
    else if(o2 -> last) o2strat = Round(*o2,o2 -> Behavior.family.cfol);
    else o2strat = Round(*o2, o2 -> Behavior.family.ufol);
  }
  else if(checkFriends(o1, o2, true))
  {
    if(o1 -> roundsSoFar == 0) o1strat = Round(*o1, o1 -> Behavior.friends.first);
    else if(o1 -> roundsThisTurn == 0) o1strat = Round(*o1, o1 -> Behavior.friends.New);
    else if(o1 -> last) o1strat = Round(*o1,o1 -> Behavior.friends.cfol);
    else o1strat = Round(*o1,o1 -> Behavior.friends.ufol);
    // for o2
    if(o2 -> roundsSoFar == 0) o2strat = Round(*o2, o2 -> Behavior.friends.first);
    else if(o2 -> roundsThisTurn == 0) o2strat = Round(*o2, o2 -> Behavior.friends.New);
    else if (o2 -> last) o2strat = Round(*o2,o2 -> Behavior.friends.cfol);
    else o2strat = Round(*o2, o2 -> Behavior.friends.ufol);
  }
  else{
    if(checkBad(o1, o2, true))
    {
      if(o1 -> roundsSoFar == 0) o1strat = Round(*o1, o1 -> Behavior.bad.first);
      else if(o1 -> roundsThisTurn == 0) o1strat = Round(*o1, o1 -> Behavior.bad.New);
      else if(o1 -> last) o1strat = Round(*o1, o1 -> Behavior.bad.cfol);
      else o1strat = Round(*o1, o1 -> Behavior.bad.ufol);
    }
    else{
      if(o1 -> roundsSoFar == 0) o1strat = Round(*o1, o1 -> Behavior.others.first);
      else if(o1 -> roundsThisTurn == 0) o1strat = Round(*o1, o1 -> Behavior.others.New);
      else if(o1 -> last) o1strat = Round(*o1, o1 -> Behavior.others.cfol);
      else o1strat = Round(*o1, o1 -> Behavior.others.ufol);
    }
    if(checkBad(o2, o1, true))
    {
      if(o2 -> roundsSoFar == 0) o2strat = Round(*o2, o2 -> Behavior.bad.first);
      else if(o2 -> roundsThisTurn == 0) o2strat = Round(*o2, o2 -> Behavior.bad.New);
      else if(o2 -> last) o2strat = Round(*o2, o2 -> Behavior.bad.cfol);
      else o2strat = Round(*o2, o2 -> Behavior.bad.ufol);
    }
    else{
      if(o2 -> roundsSoFar == 0) o2strat = Round(*o2, o2 -> Behavior.others.first);
      else if(o2 -> roundsThisTurn == 0) o2strat = Round(*o2, o2 -> Behavior.others.New);
      else if(o2 -> last) o2strat = Round(*o2, o2 -> Behavior.others.cfol);
      else o2strat = Round(*o2, o2 -> Behavior.others.ufol);
    }
  }
  // we now have o1strat and o2strat, let's get the results
  if(o1strat && o2strat ) // both cooperate
  {
    o1 -> resources += 3;
    o2 -> resources +=3;
    o1 -> OthersHistory++;
    o2 -> OthersHistory++;
    o1 -> personalhistory++;
    o2 -> personalhistory++;
    o1 -> interactionsThisTurn++;
    o2 -> interactionsThisTurn++;
  }
  else if(o1strat) // only o1 cooperates
  {
    o2 -> resources += 5;
    o2 -> OthersHistory++;
    o1 -> personalhistory++;
    o2 -> interactionsThisTurn++;

  }
  else if(o2strat)
  {
    o1 -> resources += 5;
    o1 -> OthersHistory++;
    o2 -> personalhistory++;
    o1 -> interactionsThisTurn++;
  }
  else // neither cooperate
  {
    o1 -> resources++;
    o2 -> resources++;
  }
  // update memory
  o1 -> last = o2strat;
  o2 -> last = o1strat;
  o1 -> roundsSoFar++;
  o2 -> roundsSoFar++;
  o1 -> roundsThisTurn++;
  o2 ->roundsThisTurn++; // this should be reset by another function
}

void environment :: takeTurn(int number)
{
  srand (time(NULL));
  int rlim = pother;
  int famlim = pother + pfamily;
  organism* o1;
  organism* o2;

  for(int i = 0; i < number; i++) // turn
  {
    setPairedOffFalse();
    int count = 0;
    while(count < organisms.size() - 1) // one pair off
    {
      string type;
      o1 = &organisms[findrandom()];
      count++;
      int random2 = rand() % 100;
      if(random2 < rlim) type = "random";
      else if(random2 < famlim)
      {
        if(check(o1, "family")) type = "family";
        else type = "random";
      }
      else
      {
        if(check(o1, "friend")) type = "friend";
        else type = "random";
      }
      bool found2 = false;
      if(type == "random")
      {
        o2 = &organisms[findrandom()];
      }
      else if(type =="family")
      {
        for(int i = 0; !found2; i++)
        {
          if(!findOrganism(o1 -> family[i]) -> pairedOff)
          {
            o2 = findOrganism(o1 -> family[i]);
            findOrganism(o1 -> family[i]) -> pairedOff = true;
            found2 = true;
          }
        }
      }
      else{
        for(int i = 0; !found2 ; i++)
        {
          if(!findOrganism(o1 -> friends[i]) -> pairedOff)
          {
            o2 = findOrganism(o1 -> friends[i]);
            findOrganism(o1 -> friends[i]) -> pairedOff = true;
            found2 = true;
          }
        }
      }
      count++;
      // now we have o1 and o2
      //cout << "Have o1 and o2" << endl;
      for(int k = 0; k < roundsPerTurn; k++) // round
      {
        faceOff(o1, o2);
      }
      // now the organisms can decide whether to make friends or put each other on a bad list
      if(float(o1 -> interactionsThisTurn)/ roundsPerTurn > o1-> Behavior.highCuttOff)
      {
        if(float(o2 -> interactionsThisTurn)/ roundsPerTurn > o2 -> Behavior.highCuttOff )
        {
          addFriend(o1, o2);
        }
      }
      if(float(o1 -> interactionsThisTurn) / roundsPerTurn < o1 -> Behavior.lowCuttOff)
      {
        addBad(o1, o2);
      }
      if(float(o2 -> interactionsThisTurn) / roundsPerTurn < o2 -> Behavior.lowCuttOff)
      {
        addBad(o2, o1);
       }
       resetOrganism(o1);
       resetOrganism(o2);
    }
    reproduce();
    while(organisms.size() > 500)reduce();
    turnsSoFar++;
    cout << "Turns so far:" << turnsSoFar << endl;
  }

}

bool environment :: checkFamily(organism* o1, organism* o2)
{
  for(int i = 0; i < o1 -> family.size(); i++)
  {
    if(o1 -> family[i] == o2 -> number ){
     return true;
   }
  }
  return false;
}
bool environment :: checkFriends(organism* o1, organism* o2, bool checkR)
{
  for(int i = 0; i < o1 -> friends.size(); i++)
  {

    if(o1 -> friends[i] == o2 -> number) return true;
  }
  if(checkR)
  {
    if(rumorFriend(o1, o2)) return true;
  }
  return false;
}

bool environment ::  checkBad(organism* o1, organism* o2, bool checkR)
{
  for(int i = 0; i < o1 -> badlist.size(); i++)
  {
    if(o1 -> badlist[i] == o2 -> number) return true;
  }
  if(checkR)
  {
    if(rumorBad(o1, o2)) return true;
  }
  return false;
}

void environment :: addFriend(organism* o1, organism* o2)
{
  if(checkFriends(o1,o2, false) || checkFamily(o1, o2)) return;

  o1 -> friends.push_back(o2 -> number);
  o2 -> friends.push_back(o1 -> number);
}

void environment :: addBad(organism* o1, organism* o2)
{
  if(checkBad(o1,o2, false) || checkFamily(o1, o2)) return;
  o1 -> badlist.push_back(o2 -> number);
}

void environment:: resetOrganism(organism* o1)
{
  o1 -> roundsThisTurn = 0;
  o1 -> interactionsThisTurn = 0;
  while(o1 -> friends.size() > memorylength)
  {
    o1 -> friends.pop_back();
    //cout << "n" << endl;
  }
  while(o1 -> badlist.size() > memorylength)
  {
    o1 -> badlist.pop_back();
  }
  while(o1 -> family.size() > memorylength)
  {
    o1 -> family.pop_back();
  }
}

void environment :: reproduce()
{
  for(int i = 0; i < organisms.size(); i++)
  {
    while(organisms[i].resources > 10)
    {
      addOrganismType(organisms[i].name);
      organisms[i].resources -= 10;
      addFamily(&organisms[i], &organisms[organisms.size() - 1]);
    }
  }
}
void environment :: addFamily(organism* parent, organism* child)
{
  child -> family.push_back(parent -> number);
  for(int i = 0; i < parent -> family.size(); i++)
  {
    child -> family.push_back(parent -> family[i]);
  }
  parent -> family.push_back(child -> number);
  resetOrganism(parent);
  resetOrganism(child);
}
void environment :: reduce()
{
  for(int i = 0; i < organisms.size(); i+= 2)
  {
    for(int j = 0; j < porganisms.size(); j++)
    {
      if(porganisms[j].name == organisms[i].name) porganisms[j].number--;
    }
    eraseFromMemory(organisms[i].number);
    organisms.erase(organisms.begin() + i);

  }
}
void environment :: setDistNeg()
{
  for(int i = 0; i < organisms.size(); i++)
  {
    organisms[i].distance = -1;
  }
}


vector<int> environment :: findDistances(organism* o)
{
  setDistNeg();
  vector<int> returnV;
  queue<int> q;
  organism* n;
  q.push(o -> number);
  o -> distance = 0;
  // lets do distances of friends and family
  while(!q.empty())
  {
    n = findOrganism(q.front());
    q.pop();
    for(int i = 0; i < n -> friends.size(); i++)
    {
      if(findOrganism(n -> friends[i]) -> distance == -1)
      {
        findOrganism(n -> friends[i]) -> distance = n -> distance + 1;
        q.push( n -> friends[i]);
        returnV.push_back(n -> friends[i]);
      }
    }
    for(int i = 0; i < n -> family.size(); i++)
    {
      if(findOrganism(n -> family[i]) -> distance == -1)
      {
        findOrganism(n -> family[i]) -> distance = n -> distance + 1;
        q.push( n -> family[i]);
        returnV.push_back(n -> family[i]);
      }
    }
  }
  return returnV;
}



bool environment :: rumorFriend(organism* o1, organism* o2)
{
  findDistances(o1);
  if(o2 -> distance != -1 && o2 -> distance <= rumorLength) return true;
  return false;
}
bool environment :: rumorBad(organism* o1, organism* o2)
{
  vector<int> f = findDistances(o1);
  for(int i =0; i < f.size(); i++)
  {
    if(findOrganism(f[i]) -> distance < rumorLength)
    {
      for(int j = 0; j < findOrganism(f[i]) -> badlist.size(); j++)
      {
        if(findOrganism(f[i])-> badlist[j] == o2 -> number) return true;
      }
    }
  }
  return false;
}

void environment :: eraseFromMemory(int number)
{
  for(int i = 0; i < organisms.size(); i++)
  {
    for(int j = 0; j < organisms[i].family.size(); j++)
    {
      if(organisms[i].family[j] == number)
      {
        organisms[i].family.erase(organisms[i].family.begin() + j);
        j--;
      }
    }
    for(int k = 0; k < organisms[i].friends.size(); k++)
    {
      if(organisms[i].friends[k] == number)
      {
        organisms[i].friends.erase(organisms[i].friends.begin() + k);
        k--;
      }
    }
    for(int l = 0; l < organisms[i].badlist.size(); l++)
    {
      if(organisms[i].badlist[l] == number)
      {
        organisms[i].badlist.erase(organisms[i].badlist.begin() + l);
        l--;
      }
    }
  }
}
